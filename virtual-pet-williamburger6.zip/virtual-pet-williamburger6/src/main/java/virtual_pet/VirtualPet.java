package virtual_pet;


public class VirtualPet {
    private int tick = 0;
    private int hunger = 25;
    private int loyalty = 25;
    private int stamina = 25;

            public int getTick() {
        return tick;
            }
        public int getLoyalty() {
            return loyalty;
    }
    public int getHunger() {
                return hunger;
    }

    public int getStamina() {
                return stamina;
    }}

