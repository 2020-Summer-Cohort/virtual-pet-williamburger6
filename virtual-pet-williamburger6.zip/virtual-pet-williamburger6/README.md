# Virtual Pet
Use numbers to interact with your pet. Different numbers allow you to do different actions with your pet.
See the HELP.md for assignment directions and guide.
